"""
Builds the images used in the write-up.

Kept in the repo so the artwork is reproducible rather than a pile of
one-off exports nobody can regenerate. Uses the same palette as the app.

Run: python scripts/make_post_images.py
Output: post-images/
"""

from __future__ import annotations

import pathlib

from PIL import Image, ImageDraw, ImageFont

OUT = pathlib.Path(__file__).resolve().parent.parent / "post-images"

PITCH_TOP = (11, 37, 32)
PITCH_BOT = (6, 23, 20)
EDGE = (29, 69, 57)
EDGE_SOFT = (20, 48, 41)
CHALK = (244, 248, 243)
DIM = (143, 169, 160)
FLOOD = (255, 209, 102)
SODIUM = (236, 106, 63)
GK = (95, 212, 168)
DEF = (90, 162, 232)
MID = (255, 209, 102)
FWD = (242, 112, 79)

FONTS = "/usr/share/fonts/truetype/dejavu/"


def cond(size):
    return ImageFont.truetype(FONTS + "DejaVuSansCondensed-Bold.ttf", size)


def body(size, bold=False):
    name = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
    return ImageFont.truetype(FONTS + name, size)


def canvas(w: int, h: int) -> Image.Image:
    """Floodlit pitch: warm glow at the top fading into deep green-black."""
    import numpy as np

    # vertical gradient
    t = (np.arange(h) / max(1, h - 1)) ** 0.75
    ramp = np.array(PITCH_TOP) + np.outer(t, np.array(PITCH_BOT) - np.array(PITCH_TOP))
    base = np.repeat(ramp[:, None, :], w, axis=1)

    # floodlight falloff, centred above the top edge
    yy, xx = np.mgrid[0:h, 0:w]
    dist = np.sqrt(((xx - w / 2) / (w * 0.62)) ** 2 + ((yy + h * 0.3) / (h * 0.85)) ** 2)
    glow = np.clip(1 - dist, 0, 1) ** 2
    base += glow[:, :, None] * np.array([34, 29, 16])

    return Image.fromarray(np.clip(base, 0, 255).astype("uint8"))


def text(d, xy, s, font, fill=CHALK, anchor="la"):
    d.text(xy, s, font=font, fill=fill, anchor=anchor)


def player_card(d, x, y, w, h, rating, pos, name, club, accent,
                rating_size=72, name_size=38, club_size=15):
    d.rectangle([x, y, x + w, y + h], fill=(13, 41, 35), outline=EDGE)
    d.rectangle([x, y, x + w, y + 4], fill=accent)
    text(d, (x + 22, y + 20), str(rating), cond(rating_size), accent)
    rw = d.textlength(str(rating), font=cond(rating_size))
    text(d, (x + 32 + rw, y + 20 + rating_size * 0.62), pos,
         cond(round(rating_size * 0.38)), accent, anchor="ls")
    # name sits off the bottom edge, club below it, never colliding
    text(d, (x + 22, y + h - club_size - name_size - 22), name, cond(name_size))
    text(d, (x + 22, y + h - club_size - 12), club, body(club_size), DIM)


def clock_bar(d, x, y, w, frac, colour=FLOOD):
    d.rounded_rectangle([x, y, x + w, y + 12], radius=6, fill=(3, 16, 13))
    d.rounded_rectangle([x, y, x + int(w * frac), y + 12], radius=6, fill=colour)


def chip(d, x, y, label, amount, font_l, font_a, border=EDGE_SOFT, lab=DIM):
    wl = d.textlength(label, font=font_l)
    wa = d.textlength(str(amount), font=font_a)
    w = int(wl + wa + 46)
    d.rounded_rectangle([x, y, x + w, y + 34], radius=17, outline=border)
    text(d, (x + 16, y + 17), label, font_l, lab, anchor="lm")
    text(d, (x + 16 + wl + 12, y + 17), str(amount), font_a, FLOOD, anchor="lm")
    return w


def scoreboard(d, x, y, w, h, managers):
    cw = w // len(managers)
    for i, (nm, left, needs, leading, proxy) in enumerate(managers):
        cx = x + i * cw
        d.rectangle([cx, y, cx + cw - 2, y + h],
                    fill=(26, 45, 29) if leading else PITCH_BOT)
        if leading:
            d.rectangle([cx, y, cx + cw - 2, y + 3], fill=FLOOD)
        text(d, (cx + 16, y + 16), nm, body(16, True))
        if proxy:
            nw = d.textlength(nm, font=body(16, True))
            d.rounded_rectangle([cx + 22 + nw, y + 15, cx + 70 + nw, y + 35],
                                radius=10, fill=DEF)
            text(d, (cx + 46 + nw, y + 25), "proxy", body(11, True), (4, 44, 83), "mm")
        text(d, (cx + 16, y + 44), str(left), cond(34), FLOOD if leading else CHALK)
        text(d, (cx + 16, y + 88), needs, body(13), DIM)


# ---------------------------------------------------------------- cover

def cover():
    w, h = 1000, 420
    img = canvas(w, h)
    d = ImageDraw.Draw(img)

    d.ellipse([34, 40, 50, 56], fill=FLOOD)
    text(d, (62, 36), "DRAFT NIGHT", cond(46))
    text(d, (40, 104), "An auction draft for a living room full of friends.", body(20), CHALK)
    text(d, (40, 140), "Whoever can't make it is bid for by a local open-weight model,", body(17), DIM)
    text(d, (40, 166), "from instructions they wrote in plain English.", body(17), DIM)

    x = 40
    for tag in ("offline", "Gemma via Ollama", "no API keys", "no cost per bid"):
        tw = d.textlength(tag, font=body(14))
        d.rounded_rectangle([x, 214, x + tw + 24, 248], radius=17, outline=EDGE)
        text(d, (x + 12, 231), tag, body(14), DIM, anchor="lm")
        x += tw + 34

    player_card(d, 620, 34, 300, 186, 91, "GK", "Niko Jovic", "FC Harbourside",
                GK, rating_size=62, name_size=32)
    text(d, (770, 242), "42", cond(74), FLOOD, anchor="ma")
    text(d, (770, 326), "with Rohit", body(17), CHALK, anchor="ma")
    clock_bar(d, 620, 362, 300, 0.46)

    img.save(OUT / "cover.png")
    print("  cover.png            1000x420")


# ---------------------------------------------------------- host screen

def host_screen():
    w, h = 1200, 760
    img = canvas(w, h)
    d = ImageDraw.Draw(img)

    d.line([(0, 52), (w, 52)], fill=EDGE_SOFT)
    d.ellipse([28, 24, 40, 36], fill=FLOOD)
    text(d, (50, 18), "DRAFT NIGHT", cond(24))
    text(d, (300, 23), "lot 14  ·  34 left in the pool", body(15), DIM)
    text(d, (w - 30, 23), "phones  192.168.1.24:7000/play", body(15), DIM, anchor="ra")

    player_card(d, 445, 96, 310, 220, 91, "GK", "Niko Jovic", "FC Harbourside · Serbia", GK)

    text(d, (600, 350), "42", cond(128), FLOOD, anchor="ma")
    text(d, (600, 476), "with Rohit", body(21), CHALK, anchor="ma")
    clock_bar(d, 420, 516, 360, 0.46)
    text(d, (600, 540), "6.4s left. Any bid puts 7 seconds back on the clock.",
         body(14), DIM, anchor="ma")

    x = 380
    for label, amt, bd, lb in [("Rohit", 42, FLOOD, CHALK),
                               ("Sam proxy", 38, EDGE_SOFT, DIM),
                               ("Dev", 31, EDGE_SOFT, DIM)]:
        x += chip(d, x, 572, label, amt, body(14), cond(17), bd, lb) + 10

    scoreboard(d, 0, 630, w, 130, [
        ("Rohit", 148, "1 GK · 2 DEF", True, False),
        ("Sam", 92, "2 DEF · 1 FWD", False, True),
        ("Dev", 61, "1 MID · 2 FWD", False, False),
        ("Arpan", 7, "1 FWD", False, False),
    ])

    img.save(OUT / "host-screen.png")
    print("  host-screen.png      1200x760")


# --------------------------------------------------------- phone screen

def phone_screen():
    w, h = 460, 880
    img = canvas(w, h)
    d = ImageDraw.Draw(img)

    text(d, (28, 30), "Rohit", body(19, True))
    text(d, (w - 28, 22), "148", cond(42), FLOOD, anchor="ra")
    d.line([(28, 84), (w - 28, 84)], fill=EDGE_SOFT)

    player_card(d, 28, 110, w - 56, 158, 91, "GK", "Niko Jovic", "FC Harbourside",
                GK, rating_size=46, name_size=28, club_size=13)

    text(d, (w // 2, 290), "42 with Rohit", body(18), DIM, anchor="ma")
    clock_bar(d, 28, 324, w - 56, 0.46)

    d.rounded_rectangle([28, 364, w - 28, 452], radius=5, fill=FLOOD)
    text(d, (w // 2, 408), "BID 43", cond(44), (6, 23, 20), anchor="mm")

    bw = (w - 56 - 20) // 3
    for i, v in enumerate([45, 48, 53]):
        bx = 28 + i * (bw + 10)
        d.rounded_rectangle([bx, 464, bx + bw, 516], radius=5, outline=EDGE)
        text(d, (bx + bw // 2, 490), str(v), cond(26), CHALK, anchor="mm")

    text(d, (28, 534), "Most you can bid: 93.  5 slots after this.", body(14), DIM)

    d.line([(28, 580), (w - 28, 580)], fill=EDGE_SOFT)
    text(d, (28, 598), "Your squad", body(14, True), DIM)
    rows = [("Marek Dahl", "DEF 84", 31), ("Bo Asante", "MID 81", 24),
            ("Ren Kowalski", "FWD 79", 18)]
    y = 630
    for nm, meta, price in rows:
        text(d, (28, y), nm, body(16))
        text(d, (28 + d.textlength(nm, font=body(16)) + 10, y + 2), meta, body(13), DIM)
        text(d, (w - 28, y), str(price), cond(19), FLOOD, anchor="ra")
        d.line([(28, y + 30), (w - 28, y + 30)], fill=EDGE_SOFT)
        y += 44
    for slot in ["GK to fill", "DEF to fill"]:
        text(d, (28, y), slot, body(15), DIM)
        d.line([(28, y + 30), (w - 28, y + 30)], fill=EDGE_SOFT)
        y += 44

    img.save(OUT / "phone-screen.png")
    print("  phone-screen.png      460x880")


# --------------------------------------------------------- architecture

def architecture():
    w, h = 1200, 640
    img = canvas(w, h)
    d = ImageDraw.Draw(img)

    text(d, (600, 36), "One model call per lot, not per bid", cond(34), CHALK, anchor="ma")
    text(d, (600, 84), "The model sets a ceiling once. Plain code does the bidding.",
         body(17), DIM, anchor="ma")

    def box(x, y, bw, bh, title, lines, accent):
        d.rectangle([x, y, x + bw, y + bh], fill=(13, 41, 35), outline=EDGE)
        d.rectangle([x, y, x + bw, y + 3], fill=accent)
        text(d, (x + 20, y + 22), title, body(17, True), accent)
        yy = y + 54
        for ln in lines:
            text(d, (x + 20, yy), ln, body(14), DIM)
            yy += 24

    box(60, 140, 330, 180, "The friend, once",
        ["Writes a strategy in plain English:", "\"pace up front, keeper early,",
         "never over 40% on one player\""], DEF)

    box(435, 140, 330, 180, "Gemma, once per lot",
        ["Reads the strategy and the squad.", "Answers one question:",
         "what is he worth, and why?", "→ { want, max_bid, reason }"], GK)

    box(810, 140, 330, 180, "Plain Python, every bid",
        ["Clamps max_bid to the hard cap.", "Checks budget, slot, increment.",
         "Raises with a human pause.", "Owns the money, always."], FLOOD)

    for x in (400, 775):
        d.line([(x, 230), (x + 25, 230)], fill=DIM, width=2)
        d.polygon([(x + 25, 225), (x + 35, 230), (x + 25, 235)], fill=DIM)

    d.rectangle([60, 380, 1140, 384], fill=EDGE_SOFT)
    text(d, (60, 406), "Why not call the model on every bid?", body(17, True), CHALK)
    text(d, (60, 440),
         "A bidding war has a dozen exchanges inside fifteen seconds. On a CPU-only laptop a small model",
         body(15), DIM)
    text(d, (60, 466),
         "needs one to three seconds for a short JSON answer. Calling it per bid would either stall the",
         body(15), DIM)
    text(d, (60, 492),
         "auction or force a model too small to read the strategy. So judgement goes to the model, and",
         body(15), DIM)
    text(d, (60, 518), "timing stays with code.", body(15), DIM)

    text(d, (60, 566), "A model that replies max_bid: 99999 produces a legal bid of exactly the cap.",
         body(15), FLOOD)
    text(d, (60, 592), "There is a test for that.", body(15), DIM)

    img.save(OUT / "architecture.png")
    print("  architecture.png     1200x640")


def main():
    OUT.mkdir(exist_ok=True)
    print(f"\n  writing to {OUT}\n")
    cover()
    host_screen()
    phone_screen()
    architecture()
    print()


if __name__ == "__main__":
    main()
