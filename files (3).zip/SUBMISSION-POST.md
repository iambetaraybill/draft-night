*This is a submission for the [Hacktoberfest Open-Source AI Challenge: Week 1](https://dev.to/challenges/hacktoberfest-week1-2026-10-05)*

---

## What I Built

Six of us play FIFA on a PS5. We were setting up a proper tournament, and the part that kept falling apart was picking squads.

We'd always done it with a spreadsheet, which produces exactly the evening you'd expect: someone reads out names, someone else quietly takes all the good ones, and two people spend twenty minutes arguing about whether the list was fair before anyone touches a controller.

An auction fixes that. Everyone gets the same budget, you bid for the players you want, and you live with the squad you built. Nobody can complain about a draft they set the prices in.

Except an auction only works if everyone turns up. And **[FRIEND'S NAME]** was going to miss it — **[ONE LINE ON WHY: night shift, exams, different city, new baby, whatever is true]**.

The usual fix is for someone in the room to "bid on his behalf," which means one of two things. Either you bid badly for him because you're busy bidding for yourself, or you quietly build yourself the better squad. Neither is a draft he'd have wanted.

So I built **Draft Night**: an auction that runs on one laptop over the living room wifi, with the TV showing the lot and everyone bidding from their phones. And anyone who can't be there gets a proxy manager — a local open-weight model that bids for them, live, against everyone in the room, inside their budget, from instructions they wrote in their own words.

**[FRIEND'S NAME]** sent me this:

> **[PASTE WHAT HE ACTUALLY WROTE. If he hasn't written it yet, send him this: "If I couldn't be at the draft and a bot bid for you, what would you tell it?" — and paste his reply verbatim, typos and all.]**

That paragraph is the whole input. No sliders, no priority rankings, no config file. He typed a few sentences into a text box and the model bid his draft.

![The TV screen during a live lot](HOST-SCREEN-IMAGE)

## Demo

**[VIDEO LINK — see the shot list I was given; 90 seconds is plenty]**

There's no deployed link, and that's deliberate rather than laziness. The whole thing runs on one laptop over a local network with no internet connection. Hosting it would undo the point of it.

![The phone view](PHONE-SCREEN-IMAGE)

Your phone shows three things: what you've got left, who's on the block, and one big button. That's all anyone can handle while six people are shouting.

## Code

{% embed https://github.com/iambetaraybill/draft-night %}

Two dependencies, Flask and requests. No build step, no npm, no bundler. Phones need a browser and the URL.

```
draftnight/
  rules.py     budgets and squad legality. no I/O, no model, no randomness
  agents.py    proxy bidders: model valuations, clamping, heuristic fallback
  room.py      state machine, clock, agent scheduling, event broadcast
  players.py   CSV loading with loose column matching
  server.py    Flask routes and the server-sent event stream
static/
  common.js    shared by both views: escaping, fetch, event stream, clock
  host.html    the TV
  play.html    phones
```

## How I Built It

**Gemma running locally through Ollama**, with structured JSON output. No API keys, no account, no network.

The design decision the whole project rests on is this one:

![One model call per lot, not per bid](ARCHITECTURE-IMAGE)

A bidding war has a dozen exchanges inside fifteen seconds. On a CPU-only laptop a small model needs one to three seconds for even a short JSON answer. Calling the model on every exchange would either stall the auction dead or force me down to a model too small to actually read a paragraph of strategy.

So the model answers one question per lot — *what is this player worth to this manager, and why?* — and deterministic code does the bidding up to that ceiling, with a randomised human-feeling pause between raises so the agents don't snipe instantly and make the room feel rigged.

Ollama's structured output takes a JSON schema and constrains generation to it, which is what makes a small model reliable enough to put in a live loop at all:

```python
PLAN_SCHEMA = {
    "type": "object",
    "properties": {
        "want": {"type": "boolean"},
        "max_bid": {"type": "integer"},
        "reason": {"type": "string"},
    },
    "required": ["want", "max_bid", "reason"],
}
```

**The model never touches money.** It suggests a ceiling; `rules.py` decides what's legal. Budgets, bid validity, roster slots, increments and the clock are all plain Python with no model anywhere near them.

That isn't a stylistic preference, it's the thing that makes an unpredictable model safe to hand a wallet. A model that replies `max_bid: 99999` produces a legal bid of exactly that manager's cap and a logged clamp:

```python
asked = int(raw.get("max_bid") or 0)
clamped = asked > cap
plan = Plan(
    want=bool(raw.get("want")) and asked >= rules.min_bid,
    max_bid=max(0, min(asked, cap)),   # the model does not get the last word
    ...
)
```

There's a test for exactly that, because "the model probably won't do that" is not a budget control.

The other rule worth naming is the reserve. Before any bid is accepted, the server checks you can still fill every remaining slot at the minimum price:

```python
def max_bid(self, m: Manager) -> int:
    slots = self.slots_left(m)
    if slots <= 0:
        return 0
    reserve = (slots - 1) * self.min_bid
    return max(0, self.budget_left(m) - reserve)
```

Without it, somebody spends 95% of their budget on one galactico and fields six empty shirts. The test I care most about spends the maximum allowed on *every single lot* and checks the squad still completes legally.

### Three bugs worth admitting to

**The agents sat out the entire first auction.** Twenty-four lots, proxy manager bought nothing. The valuations were fine — the model wanted players. My test harness was closing each lot the instant it opened, faster than the agents' deliberately human reaction delay. The bug wasn't in the agent; it was that my timings were hardcoded constants with no way to run fast without also running *unfairly* fast. Timings are configurable now, and the agents get a guaranteed reaction window once their plans land.

**A test passed for the wrong reason, which is worse than failing.** I had an assertion that an absurd overbid gets refused. It checked for HTTP 400 and nothing else. In CI it was getting 400 — but for "nothing is up for auction right now," because the host token didn't match and the auction had never started. A test that goes green while the feature is broken is actively harmful. It now asserts the refusal actually mentions the budget limit.

**The TV rebuild ate the host's typing.** The host screen re-renders once a second to keep the clock honest. If someone joined from their phone while you were halfway through typing a friend's strategy into the textarea, your text vanished. Now only the changed regions get patched, and in-progress input is held across rebuilds.

### Tests

36 unit tests, plus an end-to-end run that drives an entire auction over HTTP and asserts every squad ends full and formation-legal, nobody goes negative, and the proxy manager actually wins players. Both run in GitHub Actions across Python 3.10 to 3.13 on every push.

CI also checks the committed sample pool still matches its generator, and that the CSV loader survives a deliberately messy two-thousand-row export.

**Measured on my own laptop** (**[YOUR SPECS: e.g. 16GB RAM, no GPU]**), running **[MODEL TAG, e.g. gemma3:4b]**: **[AVG]** ms average per valuation, **[N]** model calls across a full draft, **[N]** clamped. The app reports all of these on the final screen.

## Why Does Open Innovation Matter?

Three reasons, none of which are about saving money.

**It has to work in a flat with bad wifi.** The whole thing runs on one laptop. Phones reach it over the local network. If the router loses its uplink mid-draft, nobody notices. A draft night that dies because an API is having an incident isn't a draft night.

**A cloud round trip would break the bidding.** Valuations have to be ready before the hammer falls. That means inference on the same machine as the auction clock, which means a model I can actually hold.

**My friends' instructions are theirs.** "Don't let **[NAME]** get a keeper" is a daft thing to ship to someone else's server, and there's no reason to. Nothing leaves the room.

There's a fourth thing I didn't expect, and it's the one that convinced me. The project ships with `--no-llm`, a heuristic fallback that bids on ratings alone so the app still works with no model installed. It was meant as a graceful degradation path.

It turned into the control group.

The heuristic can read a rating. It cannot read *"get a keeper early so I'm not stuck with whoever's left."* It cannot read *"don't let **[NAME]** get a striker."* Running both over the same pool, with the same budgets, is the clearest possible demonstration of what the open model is actually contributing — and I could only build that comparison because swapping the model out is a one-line change and running it a hundred times costs nothing.

Closed APIs give you a better model. Open weights gave me a model I could put *inside* the thing, on the critical path, in a living room with the internet off, and then run the whole evening again with it removed to see what it was worth.

## Prize Categories

**Gemma** — Gemma runs locally through Ollama as the proxy bidders' judgement layer, with schema-constrained JSON output. **[DELETE THIS LINE IF YOU END UP RUNNING A DIFFERENT MODEL]**

---

**[OPTIONAL CLOSING — only include if true:]** We ran the real draft on **[DATE]**. **[FRIEND'S NAME]**'s proxy **[WHAT HAPPENED — won him someone, got outbid, blew the budget on one player]**. He said: **[QUOTE]**.
